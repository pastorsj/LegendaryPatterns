package problem;

public interface IEncryption {
	public char encrypt(char plain);
}
