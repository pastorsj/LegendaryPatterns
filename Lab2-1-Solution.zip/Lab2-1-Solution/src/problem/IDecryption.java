package problem;

public interface IDecryption {
	public char decrypt(char cipher);
}
